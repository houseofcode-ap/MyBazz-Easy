<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "mbe";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);