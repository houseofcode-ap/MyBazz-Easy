<?php

session_start();
echo "ola";

?>